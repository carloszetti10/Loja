package com.emailapi.service;

import com.emailapi.dto.EmailRequest;
import com.emailapi.dto.EmailResponse;
import com.emailapi.entity.EmailLog;
import com.emailapi.repository.EmailLogRepository;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private EmailLogRepository emailLogRepository;

    public EmailResponse sendEmail(EmailRequest request) {
        logger.info("Iniciando envio de email para: {}", request.getTo());
        
        EmailLog emailLog = createEmailLog(request);
        
        try {
            MimeMessage message = createMimeMessage(request);
            mailSender.send(message);
            
            // Atualizar log com sucesso
            emailLog.setStatus(EmailLog.EmailStatus.SUCCESS);
            emailLog.setMessageId(message.getMessageID());
            emailLog.setSentAt(LocalDateTime.now());
            emailLogRepository.save(emailLog);
            
            logger.info("Email enviado com sucesso. ID: {}", message.getMessageID());
            return EmailResponse.success("Email enviado com sucesso!", message.getMessageID());
            
        } catch (Exception e) {
            logger.error("Erro ao enviar email: {}", e.getMessage(), e);
            
            // Atualizar log com erro
            emailLog.setStatus(EmailLog.EmailStatus.FAILED);
            emailLog.setErrorMessage(e.getMessage());
            emailLogRepository.save(emailLog);
            
            return EmailResponse.error("Erro ao enviar email", e.getMessage());
        }
    }

    @Async
    public CompletableFuture<EmailResponse> sendEmailAsync(EmailRequest request) {
        return CompletableFuture.completedFuture(sendEmail(request));
    }

    private MimeMessage createMimeMessage(EmailRequest request) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(request.getFrom());
        helper.setTo(request.getTo().toArray(new String[0]));
        
        if (request.getCc() != null && !request.getCc().isEmpty()) {
            helper.setCc(request.getCc().toArray(new String[0]));
        }
        
        if (request.getBcc() != null && !request.getBcc().isEmpty()) {
            helper.setBcc(request.getBcc().toArray(new String[0]));
        }

        helper.setSubject(request.getSubject());
        helper.setText(request.getBody(), request.isHtml());

        // Adicionar anexos se existirem
        if (request.getAttachmentPaths() != null) {
            for (String attachmentPath : request.getAttachmentPaths()) {
                File file = new File(attachmentPath);
                if (file.exists()) {
                    FileSystemResource fileResource = new FileSystemResource(file);
                    helper.addAttachment(file.getName(), fileResource);
                }
            }
        }

        return message;
    }

    private EmailLog createEmailLog(EmailRequest request) {
        EmailLog log = new EmailLog();
        log.setFromEmail(request.getFrom());
        log.setToEmails(String.join(", ", request.getTo()));
        
        if (request.getCc() != null && !request.getCc().isEmpty()) {
            log.setCcEmails(String.join(", ", request.getCc()));
        }
        
        if (request.getBcc() != null && !request.getBcc().isEmpty()) {
            log.setBccEmails(String.join(", ", request.getBcc()));
        }
        
        log.setSubject(request.getSubject());
        log.setBody(request.getBody());
        log.setHtml(request.isHtml());
        log.setStatus(EmailLog.EmailStatus.PENDING);
        
        return emailLogRepository.save(log);
    }

    public List<EmailLog> getAllLogs() {
        return emailLogRepository.findAll();
    }

    public List<EmailLog> getLogsByStatus(EmailLog.EmailStatus status) {
        return emailLogRepository.findByStatusOrderBySentAtDesc(status);
    }

    public List<EmailLog> getLogsByDateRange(LocalDateTime start, LocalDateTime end) {
        return emailLogRepository.findBySentAtBetweenOrderBySentAtDesc(start, end);
    }

    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        
        long total = emailLogRepository.count();
        long success = emailLogRepository.countByStatus(EmailLog.EmailStatus.SUCCESS);
        long failed = emailLogRepository.countByStatus(EmailLog.EmailStatus.FAILED);
        
        stats.put("total", total);
        stats.put("success", success);
        stats.put("failed", failed);
        stats.put("successRate", total > 0 ? (double) success / total * 100 : 0);
        
        // Estatísticas dos últimos 7 dias
        LocalDateTime weekAgo = LocalDateTime.now().minusDays(7);
        long weekTotal = emailLogRepository.countEmailsSince(weekAgo);
        long weekSuccess = emailLogRepository.countEmailsByStatusSince(EmailLog.EmailStatus.SUCCESS, weekAgo);
        
        stats.put("weekTotal", weekTotal);
        stats.put("weekSuccess", weekSuccess);
        
        return stats;
    }
}