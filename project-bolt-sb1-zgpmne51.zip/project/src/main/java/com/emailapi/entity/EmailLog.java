package com.emailapi.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "email_logs")
public class EmailLog {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "from_email", nullable = false)
    private String fromEmail;
    
    @Column(name = "to_emails", columnDefinition = "TEXT")
    private String toEmails;
    
    @Column(name = "cc_emails", columnDefinition = "TEXT")
    private String ccEmails;
    
    @Column(name = "bcc_emails", columnDefinition = "TEXT")
    private String bccEmails;
    
    @Column(nullable = false)
    private String subject;
    
    @Column(columnDefinition = "TEXT")
    private String body;
    
    @Column(name = "is_html")
    private boolean isHtml;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmailStatus status;
    
    @Column(name = "message_id")
    private String messageId;
    
    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;
    
    @Column(name = "sent_at", nullable = false)
    private LocalDateTime sentAt;
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    // Enum para status
    public enum EmailStatus {
        SUCCESS, FAILED, PENDING
    }

    // Constructors
    public EmailLog() {
        this.createdAt = LocalDateTime.now();
        this.sentAt = LocalDateTime.now();
    }

    public EmailLog(String fromEmail, String toEmails, String subject, String body, boolean isHtml) {
        this();
        this.fromEmail = fromEmail;
        this.toEmails = toEmails;
        this.subject = subject;
        this.body = body;
        this.isHtml = isHtml;
        this.status = EmailStatus.PENDING;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getToEmails() {
        return toEmails;
    }

    public void setToEmails(String toEmails) {
        this.toEmails = toEmails;
    }

    public String getCcEmails() {
        return ccEmails;
    }

    public void setCcEmails(String ccEmails) {
        this.ccEmails = ccEmails;
    }

    public String getBccEmails() {
        return bccEmails;
    }

    public void setBccEmails(String bccEmails) {
        this.bccEmails = bccEmails;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public boolean isHtml() {
        return isHtml;
    }

    public void setHtml(boolean html) {
        isHtml = html;
    }

    public EmailStatus getStatus() {
        return status;
    }

    public void setStatus(EmailStatus status) {
        this.status = status;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "EmailLog{" +
                "id=" + id +
                ", fromEmail='" + fromEmail + '\'' +
                ", toEmails='" + toEmails + '\'' +
                ", subject='" + subject + '\'' +
                ", status=" + status +
                ", sentAt=" + sentAt +
                '}';
    }
}