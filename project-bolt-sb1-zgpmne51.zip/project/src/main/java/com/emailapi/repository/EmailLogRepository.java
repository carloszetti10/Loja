package com.emailapi.repository;

import com.emailapi.entity.EmailLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EmailLogRepository extends JpaRepository<EmailLog, Long> {
    
    // Buscar por status
    List<EmailLog> findByStatusOrderBySentAtDesc(EmailLog.EmailStatus status);
    
    // Buscar por período
    List<EmailLog> findBySentAtBetweenOrderBySentAtDesc(LocalDateTime start, LocalDateTime end);
    
    // Buscar por remetente
    List<EmailLog> findByFromEmailContainingIgnoreCaseOrderBySentAtDesc(String fromEmail);
    
    // Buscar por destinatário
    @Query("SELECT e FROM EmailLog e WHERE e.toEmails LIKE %:email% ORDER BY e.sentAt DESC")
    List<EmailLog> findByToEmailsContaining(@Param("email") String email);
    
    // Contar por status
    long countByStatus(EmailLog.EmailStatus status);
    
    // Estatísticas por período
    @Query("SELECT COUNT(e) FROM EmailLog e WHERE e.sentAt >= :startDate")
    long countEmailsSince(@Param("startDate") LocalDateTime startDate);
    
    @Query("SELECT COUNT(e) FROM EmailLog e WHERE e.status = :status AND e.sentAt >= :startDate")
    long countEmailsByStatusSince(@Param("status") EmailLog.EmailStatus status, @Param("startDate") LocalDateTime startDate);
    
    // Buscar últimos emails
    List<EmailLog> findTop10ByOrderBySentAtDesc();
    
    // Buscar emails por assunto
    List<EmailLog> findBySubjectContainingIgnoreCaseOrderBySentAtDesc(String subject);
}