package com.emailapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class EmailSenderApiApplication {

    public static void main(String[] args) {
        // Configurar propriedades do sistema para JavaFX
        System.setProperty("javafx.preloader", "com.sun.javafx.application.LauncherImpl");
        
        SpringApplication.run(EmailSenderApiApplication.class, args);
        
        // Iniciar JavaFX em uma thread separada
        new Thread(() -> {
            try {
                Thread.sleep(2000); // Aguardar Spring Boot inicializar
                com.emailapi.javafx.EmailSenderApplication.launchJavaFX(args);
            } catch (Exception e) {
                System.err.println("Erro ao iniciar JavaFX: " + e.getMessage());
            }
        }).start();
    }
}