package com.emailapi.controller;

import com.emailapi.dto.EmailRequest;
import com.emailapi.dto.EmailResponse;
import com.emailapi.entity.EmailLog;
import com.emailapi.service.EmailService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/email")
@CrossOrigin(origins = "*")
public class EmailController {

    private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    private EmailService emailService;

    @PostMapping("/send")
    public ResponseEntity<EmailResponse> sendEmail(@Valid @RequestBody EmailRequest request, 
                                                  BindingResult bindingResult) {
        logger.info("Recebida solicitação de envio de email para: {}", request.getTo());
        
        if (bindingResult.hasErrors()) {
            StringBuilder errors = new StringBuilder();
            bindingResult.getAllErrors().forEach(error -> 
                errors.append(error.getDefaultMessage()).append("; "));
            
            return ResponseEntity.badRequest()
                .body(EmailResponse.error("Dados inválidos", errors.toString()));
        }

        try {
            EmailResponse response = emailService.sendEmail(request);
            
            if (response.isSuccess()) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
            
        } catch (Exception e) {
            logger.error("Erro inesperado ao enviar email: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(EmailResponse.error("Erro interno do servidor", e.getMessage()));
        }
    }

    @PostMapping("/send-async")
    public ResponseEntity<Map<String, String>> sendEmailAsync(@Valid @RequestBody EmailRequest request) {
        logger.info("Recebida solicitação de envio assíncrono de email para: {}", request.getTo());
        
        CompletableFuture<EmailResponse> future = emailService.sendEmailAsync(request);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Email sendo processado assincronamente");
        response.put("status", "PROCESSING");
        
        return ResponseEntity.accepted().body(response);
    }

    @GetMapping("/logs")
    public ResponseEntity<List<EmailLog>> getAllLogs() {
        List<EmailLog> logs = emailService.getAllLogs();
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/logs/status/{status}")
    public ResponseEntity<List<EmailLog>> getLogsByStatus(@PathVariable EmailLog.EmailStatus status) {
        List<EmailLog> logs = emailService.getLogsByStatus(status);
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/logs/date-range")
    public ResponseEntity<List<EmailLog>> getLogsByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        
        List<EmailLog> logs = emailService.getLogsByDateRange(start, end);
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        Map<String, Object> stats = emailService.getStatistics();
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("timestamp", LocalDateTime.now());
        health.put("service", "Email API");
        health.put("version", "1.0.0");
        
        return ResponseEntity.ok(health);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<EmailResponse> handleException(Exception e) {
        logger.error("Erro não tratado: {}", e.getMessage(), e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(EmailResponse.error("Erro interno do servidor", e.getMessage()));
    }
}