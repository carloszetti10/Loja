package com.emailapi.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public class EmailRequest {
    
    @NotBlank(message = "Campo 'from' é obrigatório")
    @Email(message = "Email 'from' deve ser válido")
    private String from;
    
    @NotEmpty(message = "Lista 'to' não pode estar vazia")
    private List<@Email(message = "Todos os emails em 'to' devem ser válidos") String> to;
    
    private List<@Email(message = "Todos os emails em 'cc' devem ser válidos") String> cc;
    
    private List<@Email(message = "Todos os emails em 'bcc' devem ser válidos") String> bcc;
    
    @NotBlank(message = "Assunto é obrigatório")
    private String subject;
    
    @NotBlank(message = "Corpo do email é obrigatório")
    private String body;
    
    private boolean isHtml = false;
    
    private List<String> attachmentPaths;

    // Constructors
    public EmailRequest() {}

    public EmailRequest(String from, List<String> to, String subject, String body) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.body = body;
    }

    // Getters and Setters
    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public List<String> getTo() {
        return to;
    }

    public void setTo(List<String> to) {
        this.to = to;
    }

    public List<String> getCc() {
        return cc;
    }

    public void setCc(List<String> cc) {
        this.cc = cc;
    }

    public List<String> getBcc() {
        return bcc;
    }

    public void setBcc(List<String> bcc) {
        this.bcc = bcc;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public boolean isHtml() {
        return isHtml;
    }

    public void setHtml(boolean html) {
        isHtml = html;
    }

    public List<String> getAttachmentPaths() {
        return attachmentPaths;
    }

    public void setAttachmentPaths(List<String> attachmentPaths) {
        this.attachmentPaths = attachmentPaths;
    }

    @Override
    public String toString() {
        return "EmailRequest{" +
                "from='" + from + '\'' +
                ", to=" + to +
                ", cc=" + cc +
                ", bcc=" + bcc +
                ", subject='" + subject + '\'' +
                ", isHtml=" + isHtml +
                ", attachmentPaths=" + attachmentPaths +
                '}';
    }
}