package com.emailapi.dto;

import java.time.LocalDateTime;

public class EmailResponse {
    
    private boolean success;
    private String message;
    private String messageId;
    private LocalDateTime timestamp;
    private String error;

    // Constructors
    public EmailResponse() {
        this.timestamp = LocalDateTime.now();
    }

    public EmailResponse(boolean success, String message) {
        this();
        this.success = success;
        this.message = message;
    }

    public EmailResponse(boolean success, String message, String messageId) {
        this(success, message);
        this.messageId = messageId;
    }

    // Static factory methods
    public static EmailResponse success(String message, String messageId) {
        return new EmailResponse(true, message, messageId);
    }

    public static EmailResponse error(String message, String error) {
        EmailResponse response = new EmailResponse(false, message);
        response.setError(error);
        return response;
    }

    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "EmailResponse{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", messageId='" + messageId + '\'' +
                ", timestamp=" + timestamp +
                ", error='" + error + '\'' +
                '}';
    }
}