package com.emailapi.javafx.controller;

import com.emailapi.dto.EmailRequest;
import com.emailapi.dto.EmailResponse;
import com.emailapi.entity.EmailLog;
import com.emailapi.javafx.service.EmailApiService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class EmailSenderController implements Initializable {

    private static final Logger logger = LoggerFactory.getLogger(EmailSenderController.class);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @FXML private TextField fromField;
    @FXML private TextField toField;
    @FXML private TextField ccField;
    @FXML private TextField bccField;
    @FXML private TextField subjectField;
    @FXML private TextArea bodyArea;
    @FXML private CheckBox htmlCheckBox;
    @FXML private ListView<String> attachmentsList;
    @FXML private Button addAttachmentButton;
    @FXML private Button removeAttachmentButton;
    @FXML private Button sendButton;
    @FXML private Button clearButton;
    @FXML private ProgressIndicator progressIndicator;
    @FXML private Label statusLabel;
    @FXML private TableView<EmailLog> logsTable;
    @FXML private TableColumn<EmailLog, String> statusColumn;
    @FXML private TableColumn<EmailLog, String> fromColumn;
    @FXML private TableColumn<EmailLog, String> toColumn;
    @FXML private TableColumn<EmailLog, String> subjectColumn;
    @FXML private TableColumn<EmailLog, String> dateColumn;
    @FXML private ComboBox<String> statusFilter;
    @FXML private Button refreshButton;
    @FXML private Label totalEmailsLabel;
    @FXML private Label successEmailsLabel;
    @FXML private Label failedEmailsLabel;
    @FXML private Label successRateLabel;

    private Stage primaryStage;
    private EmailApiService emailApiService;
    private ObservableList<String> attachments;
    private ObservableList<EmailLog> emailLogs;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        logger.info("Inicializando controller JavaFX...");
        
        emailApiService = new EmailApiService();
        attachments = FXCollections.observableArrayList();
        emailLogs = FXCollections.observableArrayList();
        
        setupUI();
        setupTableView();
        setupEventHandlers();
        loadInitialData();
        
        logger.info("Controller JavaFX inicializado com sucesso!");
    }

    private void setupUI() {
        // Configurar lista de anexos
        attachmentsList.setItems(attachments);
        
        // Configurar filtro de status
        statusFilter.setItems(FXCollections.observableArrayList("TODOS", "SUCCESS", "FAILED"));
        statusFilter.setValue("TODOS");
        
        // Configurar estado inicial
        progressIndicator.setVisible(false);
        statusLabel.setText("Pronto para enviar emails");
        
        // Configurar campos obrigatórios
        fromField.setPromptText("seu-email@gmail.com");
        toField.setPromptText("destinatario@exemplo.com, outro@exemplo.com");
        subjectField.setPromptText("Assunto do email");
        bodyArea.setPromptText("Digite sua mensagem aqui...");
    }

    private void setupTableView() {
        // Configurar colunas da tabela
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        fromColumn.setCellValueFactory(new PropertyValueFactory<>("fromEmail"));
        toColumn.setCellValueFactory(new PropertyValueFactory<>("toEmails"));
        subjectColumn.setCellValueFactory(new PropertyValueFactory<>("subject"));
        
        dateColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().getSentAt() != null) {
                return new javafx.beans.property.SimpleStringProperty(
                    cellData.getValue().getSentAt().format(DATE_FORMATTER));
            }
            return new javafx.beans.property.SimpleStringProperty("");
        });

        // Configurar cores para status
        statusColumn.setCellFactory(column -> new TableCell<EmailLog, String>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status);
                    if ("SUCCESS".equals(status)) {
                        setStyle("-fx-text-fill: #059669; -fx-font-weight: bold;");
                    } else if ("FAILED".equals(status)) {
                        setStyle("-fx-text-fill: #dc2626; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #6b7280;");
                    }
                }
            }
        });

        logsTable.setItems(emailLogs);
    }

    private void setupEventHandlers() {
        sendButton.setOnAction(e -> sendEmail());
        clearButton.setOnAction(e -> clearForm());
        addAttachmentButton.setOnAction(e -> addAttachment());
        removeAttachmentButton.setOnAction(e -> removeSelectedAttachment());
        refreshButton.setOnAction(e -> loadEmailLogs());
        statusFilter.setOnAction(e -> loadEmailLogs());
        
        // Validação em tempo real
        fromField.textProperty().addListener((obs, oldVal, newVal) -> validateForm());
        toField.textProperty().addListener((obs, oldVal, newVal) -> validateForm());
        subjectField.textProperty().addListener((obs, oldVal, newVal) -> validateForm());
        bodyArea.textProperty().addListener((obs, oldVal, newVal) -> validateForm());
    }

    private void loadInitialData() {
        loadEmailLogs();
        loadStatistics();
        
        // Auto-refresh a cada 30 segundos
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(30), e -> {
            loadEmailLogs();
            loadStatistics();
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    @FXML
    private void sendEmail() {
        if (!validateForm()) {
            showError("Por favor, preencha todos os campos obrigatórios.");
            return;
        }

        EmailRequest request = createEmailRequest();
        
        Task<EmailResponse> task = new Task<EmailResponse>() {
            @Override
            protected EmailResponse call() throws Exception {
                return emailApiService.sendEmail(request);
            }

            @Override
            protected void succeeded() {
                Platform.runLater(() -> {
                    EmailResponse response = getValue();
                    if (response.isSuccess()) {
                        showSuccess("Email enviado com sucesso! ✅");
                        clearForm();
                        loadEmailLogs();
                        loadStatistics();
                    } else {
                        showError("Erro ao enviar email: " + response.getMessage());
                    }
                    setLoading(false);
                });
            }

            @Override
            protected void failed() {
                Platform.runLater(() -> {
                    showError("Erro de conexão. Verifique se a API está rodando.");
                    setLoading(false);
                });
            }
        };

        setLoading(true);
        new Thread(task).start();
    }

    private EmailRequest createEmailRequest() {
        EmailRequest request = new EmailRequest();
        request.setFrom(fromField.getText().trim());
        request.setTo(parseEmailList(toField.getText()));
        request.setCc(parseEmailList(ccField.getText()));
        request.setBcc(parseEmailList(bccField.getText()));
        request.setSubject(subjectField.getText().trim());
        request.setBody(bodyArea.getText());
        request.setHtml(htmlCheckBox.isSelected());
        
        if (!attachments.isEmpty()) {
            request.setAttachmentPaths(new ArrayList<>(attachments));
        }
        
        return request;
    }

    private List<String> parseEmailList(String emailString) {
        if (emailString == null || emailString.trim().isEmpty()) {
            return new ArrayList<>();
        }
        return Arrays.stream(emailString.split(","))
                .map(String::trim)
                .filter(email -> !email.isEmpty())
                .collect(Collectors.toList());
    }

    private boolean validateForm() {
        boolean isValid = !fromField.getText().trim().isEmpty() &&
                         !toField.getText().trim().isEmpty() &&
                         !subjectField.getText().trim().isEmpty() &&
                         !bodyArea.getText().trim().isEmpty();
        
        sendButton.setDisable(!isValid);
        return isValid;
    }

    @FXML
    private void clearForm() {
        fromField.clear();
        toField.clear();
        ccField.clear();
        bccField.clear();
        subjectField.clear();
        bodyArea.clear();
        htmlCheckBox.setSelected(false);
        attachments.clear();
        statusLabel.setText("Formulário limpo");
    }

    @FXML
    private void addAttachment() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecionar Anexo");
        
        List<File> files = fileChooser.showOpenMultipleDialog(primaryStage);
        if (files != null) {
            for (File file : files) {
                if (!attachments.contains(file.getAbsolutePath())) {
                    attachments.add(file.getAbsolutePath());
                }
            }
            statusLabel.setText(files.size() + " arquivo(s) adicionado(s)");
        }
    }

    @FXML
    private void removeSelectedAttachment() {
        String selected = attachmentsList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            attachments.remove(selected);
            statusLabel.setText("Anexo removido");
        }
    }

    private void loadEmailLogs() {
        Task<List<EmailLog>> task = new Task<List<EmailLog>>() {
            @Override
            protected List<EmailLog> call() throws Exception {
                String status = statusFilter.getValue();
                if ("TODOS".equals(status)) {
                    return emailApiService.getAllLogs();
                } else {
                    return emailApiService.getLogsByStatus(status);
                }
            }

            @Override
            protected void succeeded() {
                Platform.runLater(() -> {
                    emailLogs.clear();
                    emailLogs.addAll(getValue());
                });
            }

            @Override
            protected void failed() {
                Platform.runLater(() -> {
                    logger.error("Erro ao carregar logs: {}", getException().getMessage());
                });
            }
        };

        new Thread(task).start();
    }

    private void loadStatistics() {
        Task<Map<String, Object>> task = new Task<Map<String, Object>>() {
            @Override
            protected Map<String, Object> call() throws Exception {
                return emailApiService.getStatistics();
            }

            @Override
            protected void succeeded() {
                Platform.runLater(() -> {
                    Map<String, Object> stats = getValue();
                    totalEmailsLabel.setText(stats.get("total").toString());
                    successEmailsLabel.setText(stats.get("success").toString());
                    failedEmailsLabel.setText(stats.get("failed").toString());
                    successRateLabel.setText(String.format("%.1f%%", (Double) stats.get("successRate")));
                });
            }
        };

        new Thread(task).start();
    }

    private void setLoading(boolean loading) {
        progressIndicator.setVisible(loading);
        sendButton.setDisable(loading);
        
        if (loading) {
            statusLabel.setText("Enviando email...");
        }
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: #059669; -fx-font-weight: bold;");
        
        // Resetar estilo após 5 segundos
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            statusLabel.setStyle("");
            statusLabel.setText("Pronto para enviar emails");
        }));
        timeline.play();
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: #dc2626; -fx-font-weight: bold;");
        
        // Resetar estilo após 5 segundos
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            statusLabel.setStyle("");
            statusLabel.setText("Pronto para enviar emails");
        }));
        timeline.play();
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
}