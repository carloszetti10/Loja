package com.emailapi.javafx.service;

import com.emailapi.dto.EmailRequest;
import com.emailapi.dto.EmailResponse;
import com.emailapi.entity.EmailLog;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class EmailApiService {

    private static final Logger logger = LoggerFactory.getLogger(EmailApiService.class);
    private static final String BASE_URL = "http://localhost:8080/api/email";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private final OkHttpClient client;
    private final ObjectMapper objectMapper;

    public EmailApiService() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    public EmailResponse sendEmail(EmailRequest request) throws IOException {
        logger.info("Enviando email via API para: {}", request.getTo());
        
        String json = objectMapper.writeValueAsString(request);
        RequestBody body = RequestBody.create(json, JSON);
        
        Request httpRequest = new Request.Builder()
                .url(BASE_URL + "/send")
                .post(body)
                .build();

        try (Response response = client.newCall(httpRequest).execute()) {
            String responseBody = response.body().string();
            
            if (response.isSuccessful()) {
                EmailResponse emailResponse = objectMapper.readValue(responseBody, EmailResponse.class);
                logger.info("Email enviado com sucesso via API");
                return emailResponse;
            } else {
                logger.error("Erro na API: {} - {}", response.code(), responseBody);
                return EmailResponse.error("Erro na API", "HTTP " + response.code() + ": " + responseBody);
            }
        }
    }

    public List<EmailLog> getAllLogs() throws IOException {
        logger.debug("Buscando todos os logs via API");
        
        Request request = new Request.Builder()
                .url(BASE_URL + "/logs")
                .get()
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                return objectMapper.readValue(responseBody, new TypeReference<List<EmailLog>>() {});
            } else {
                logger.error("Erro ao buscar logs: {}", response.code());
                throw new IOException("Erro ao buscar logs: HTTP " + response.code());
            }
        }
    }

    public List<EmailLog> getLogsByStatus(String status) throws IOException {
        logger.debug("Buscando logs por status: {}", status);
        
        Request request = new Request.Builder()
                .url(BASE_URL + "/logs/status/" + status)
                .get()
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                return objectMapper.readValue(responseBody, new TypeReference<List<EmailLog>>() {});
            } else {
                logger.error("Erro ao buscar logs por status: {}", response.code());
                throw new IOException("Erro ao buscar logs: HTTP " + response.code());
            }
        }
    }

    public Map<String, Object> getStatistics() throws IOException {
        logger.debug("Buscando estatísticas via API");
        
        Request request = new Request.Builder()
                .url(BASE_URL + "/statistics")
                .get()
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                return objectMapper.readValue(responseBody, new TypeReference<Map<String, Object>>() {});
            } else {
                logger.error("Erro ao buscar estatísticas: {}", response.code());
                throw new IOException("Erro ao buscar estatísticas: HTTP " + response.code());
            }
        }
    }

    public boolean isApiHealthy() {
        try {
            Request request = new Request.Builder()
                    .url(BASE_URL + "/health")
                    .get()
                    .build();

            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
        } catch (IOException e) {
            logger.warn("API não está respondendo: {}", e.getMessage());
            return false;
        }
    }
}