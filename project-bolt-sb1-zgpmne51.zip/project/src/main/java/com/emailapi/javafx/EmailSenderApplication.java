package com.emailapi.javafx;

import com.emailapi.javafx.controller.EmailSenderController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmailSenderApplication extends Application {

    private static final Logger logger = LoggerFactory.getLogger(EmailSenderApplication.class);
    private static String[] args;

    public static void launchJavaFX(String[] arguments) {
        args = arguments;
        launch(arguments);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            logger.info("Iniciando aplicação JavaFX...");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/email-sender.fxml"));
            Parent root = loader.load();

            // Obter o controller e configurar
            EmailSenderController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);

            Scene scene = new Scene(root, 1200, 800);
            scene.getStylesheets().add(getClass().getResource("/css/email-sender.css").toExternalForm());

            primaryStage.setTitle("📧 Email Sender API - Interface JavaFX");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(600);
            
            // Adicionar ícone se disponível
            try {
                primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/icons/email-icon.png")));
            } catch (Exception e) {
                logger.warn("Ícone não encontrado, usando padrão");
            }

            primaryStage.show();
            logger.info("Aplicação JavaFX iniciada com sucesso!");

        } catch (Exception e) {
            logger.error("Erro ao iniciar aplicação JavaFX: {}", e.getMessage(), e);
        }
    }

    @Override
    public void stop() {
        logger.info("Encerrando aplicação JavaFX...");
    }

    public static void main(String[] args) {
        launch(args);
    }
}