import express from 'express';
import nodemailer from 'nodemailer';
import cors from 'cors';
import multer from 'multer';
import Joi from 'joi';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Configuração do multer para upload de arquivos
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

// Armazenamento em memória para logs (em produção, usar banco de dados)
let emailLogs = [];
let emailStats = {
  total: 0,
  success: 0,
  failed: 0
};

// Configuração do transportador de email
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: process.env.EMAIL_PORT || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USERNAME || 'seu-email@gmail.com',
      pass: process.env.EMAIL_PASSWORD || 'sua-senha-de-app'
    }
  });
};

// Validação de email
const emailSchema = Joi.object({
  from: Joi.string().email().required(),
  to: Joi.array().items(Joi.string().email()).min(1).required(),
  cc: Joi.array().items(Joi.string().email()).optional(),
  bcc: Joi.array().items(Joi.string().email()).optional(),
  subject: Joi.string().required(),
  body: Joi.string().required(),
  isHtml: Joi.boolean().default(false)
});

// Rota principal - serve a interface web
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Endpoint para enviar email
app.post('/api/email/send', upload.array('attachments'), async (req, res) => {
  try {
    // Validar dados
    const { error, value } = emailSchema.validate(JSON.parse(req.body.emailData || '{}'));
    if (error) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: error.details.map(d => d.message)
      });
    }

    const emailData = value;
    const transporter = createTransporter();

    // Preparar opções do email
    const mailOptions = {
      from: emailData.from,
      to: emailData.to.join(', '),
      cc: emailData.cc ? emailData.cc.join(', ') : undefined,
      bcc: emailData.bcc ? emailData.bcc.join(', ') : undefined,
      subject: emailData.subject,
      [emailData.isHtml ? 'html' : 'text']: emailData.body,
      attachments: req.files ? req.files.map(file => ({
        filename: file.originalname,
        path: file.path
      })) : undefined
    };

    // Enviar email
    const info = await transporter.sendMail(mailOptions);

    // Registrar log
    const log = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      from: emailData.from,
      to: emailData.to,
      subject: emailData.subject,
      status: 'SUCCESS',
      messageId: info.messageId,
      response: info.response
    };

    emailLogs.unshift(log);
    emailStats.total++;
    emailStats.success++;

    res.json({
      success: true,
      message: 'Email enviado com sucesso!',
      messageId: info.messageId,
      log: log
    });

  } catch (error) {
    console.error('Erro ao enviar email:', error);

    // Registrar log de erro
    const errorLog = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      from: req.body.from || 'unknown',
      to: req.body.to || [],
      subject: req.body.subject || 'unknown',
      status: 'FAILED',
      error: error.message
    };

    emailLogs.unshift(errorLog);
    emailStats.total++;
    emailStats.failed++;

    res.status(500).json({
      success: false,
      message: 'Erro ao enviar email',
      error: error.message,
      log: errorLog
    });
  }
});

// Endpoint para buscar logs
app.get('/api/email/logs', (req, res) => {
  const { status, limit = 50 } = req.query;
  
  let filteredLogs = emailLogs;
  if (status) {
    filteredLogs = emailLogs.filter(log => log.status === status.toUpperCase());
  }

  res.json({
    success: true,
    logs: filteredLogs.slice(0, parseInt(limit)),
    total: filteredLogs.length
  });
});

// Endpoint para estatísticas
app.get('/api/email/statistics', (req, res) => {
  res.json({
    success: true,
    statistics: {
      ...emailStats,
      successRate: emailStats.total > 0 ? (emailStats.success / emailStats.total * 100).toFixed(2) : 0
    }
  });
});

// Endpoint para health check
app.get('/api/email/health', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📧 API de Email disponível em http://localhost:${PORT}`);
  console.log(`🌐 Interface web em http://localhost:${PORT}`);
  console.log('');
  console.log('📋 Configuração necessária:');
  console.log('   EMAIL_USERNAME=seu-email@gmail.com');
  console.log('   EMAIL_PASSWORD=sua-senha-de-app');
});