class EmailSenderApp {
    constructor() {
        this.initializeElements();
        this.attachEventListeners();
        this.loadStatistics();
        this.loadLogs();
    }

    initializeElements() {
        this.form = document.getElementById('emailForm');
        this.sendButton = document.getElementById('sendButton');
        this.buttonText = this.sendButton.querySelector('.button-text');
        this.loadingSpinner = this.sendButton.querySelector('.loading-spinner');
        this.resultDiv = document.getElementById('result');
        this.statusFilter = document.getElementById('statusFilter');
        this.refreshButton = document.getElementById('refreshLogs');
        this.logsContainer = document.getElementById('logsContainer');
        
        // Elementos de estatísticas
        this.totalEmails = document.getElementById('totalEmails');
        this.successEmails = document.getElementById('successEmails');
        this.failedEmails = document.getElementById('failedEmails');
        this.successRate = document.getElementById('successRate');
    }

    attachEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        this.statusFilter.addEventListener('change', () => this.loadLogs());
        this.refreshButton.addEventListener('click', () => {
            this.loadStatistics();
            this.loadLogs();
        });

        // Auto-refresh a cada 30 segundos
        setInterval(() => {
            this.loadStatistics();
            this.loadLogs();
        }, 30000);
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        this.setLoading(true);
        this.hideResult();

        try {
            const formData = new FormData();
            
            // Preparar dados do email
            const emailData = {
                from: document.getElementById('from').value,
                to: this.parseEmailList(document.getElementById('to').value),
                cc: this.parseEmailList(document.getElementById('cc').value),
                bcc: this.parseEmailList(document.getElementById('bcc').value),
                subject: document.getElementById('subject').value,
                body: document.getElementById('body').value,
                isHtml: document.getElementById('isHtml').checked
            };

            formData.append('emailData', JSON.stringify(emailData));

            // Adicionar anexos
            const attachments = document.getElementById('attachments').files;
            for (let i = 0; i < attachments.length; i++) {
                formData.append('attachments', attachments[i]);
            }

            const response = await fetch('/api/email/send', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                this.showResult('Email enviado com sucesso! ✅', 'success');
                this.form.reset();
                this.loadStatistics();
                this.loadLogs();
            } else {
                this.showResult(`Erro: ${result.message}`, 'error');
            }

        } catch (error) {
            console.error('Erro ao enviar email:', error);
            this.showResult('Erro de conexão. Verifique se o servidor está rodando.', 'error');
        } finally {
            this.setLoading(false);
        }
    }

    parseEmailList(emailString) {
        if (!emailString || emailString.trim() === '') return [];
        return emailString.split(',').map(email => email.trim()).filter(email => email);
    }

    setLoading(loading) {
        this.sendButton.disabled = loading;
        if (loading) {
            this.buttonText.style.display = 'none';
            this.loadingSpinner.style.display = 'inline';
        } else {
            this.buttonText.style.display = 'inline';
            this.loadingSpinner.style.display = 'none';
        }
    }

    showResult(message, type) {
        this.resultDiv.textContent = message;
        this.resultDiv.className = `result-message ${type}`;
        this.resultDiv.style.display = 'block';
        
        // Auto-hide após 5 segundos
        setTimeout(() => this.hideResult(), 5000);
    }

    hideResult() {
        this.resultDiv.style.display = 'none';
    }

    async loadStatistics() {
        try {
            const response = await fetch('/api/email/statistics');
            const result = await response.json();
            
            if (result.success) {
                const stats = result.statistics;
                this.totalEmails.textContent = stats.total;
                this.successEmails.textContent = stats.success;
                this.failedEmails.textContent = stats.failed;
                this.successRate.textContent = `${stats.successRate}%`;
            }
        } catch (error) {
            console.error('Erro ao carregar estatísticas:', error);
        }
    }

    async loadLogs() {
        try {
            const status = this.statusFilter.value;
            const url = status ? `/api/email/logs?status=${status}` : '/api/email/logs';
            
            const response = await fetch(url);
            const result = await response.json();
            
            if (result.success) {
                this.renderLogs(result.logs);
            }
        } catch (error) {
            console.error('Erro ao carregar logs:', error);
            this.logsContainer.innerHTML = '<div class="no-logs">Erro ao carregar histórico</div>';
        }
    }

    renderLogs(logs) {
        if (!logs || logs.length === 0) {
            this.logsContainer.innerHTML = '<div class="no-logs">Nenhum email encontrado</div>';
            return;
        }

        const logsHtml = logs.map(log => `
            <div class="log-item">
                <div class="log-header">
                    <span class="log-status ${log.status.toLowerCase()}">${log.status}</span>
                    <span class="log-time">${this.formatDate(log.timestamp)}</span>
                </div>
                <div class="log-details">
                    <div class="log-subject">${log.subject}</div>
                    <div class="log-recipients">
                        <strong>De:</strong> ${log.from}<br>
                        <strong>Para:</strong> ${Array.isArray(log.to) ? log.to.join(', ') : log.to}
                        ${log.error ? `<br><strong>Erro:</strong> ${log.error}` : ''}
                    </div>
                </div>
            </div>
        `).join('');

        this.logsContainer.innerHTML = logsHtml;
    }

    formatDate(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}

// Inicializar aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    new EmailSenderApp();
});