# Email Sender API - Spring Boot + JavaFX

Uma aplicação completa para envio de emails com API REST Spring Boot e interface gráfica JavaFX.

## 🚀 Funcionalidades

### API REST (Spring Boot)
- ✅ Envio de emails via SMTP
- ✅ Suporte a HTML e texto simples
- ✅ Múltiplos destinatários (TO, CC, BCC)
- ✅ Anexos de arquivo
- ✅ Histórico de emails enviados
- ✅ Estatísticas de envio
- ✅ Logs detalhados
- ✅ Validação de dados
- ✅ Tratamento de erros

### Interface JavaFX
- ✅ Interface moderna e intuitiva
- ✅ Formulário completo para composição de emails
- ✅ Visualização de histórico
- ✅ Estatísticas em tempo real
- ✅ Feedback visual para operações
- ✅ Suporte a anexos
- ✅ Validação em tempo real

## 🛠️ Tecnologias

- **Java 17**
- **Spring Boot 3.2**
- **JavaFX 21**
- **H2 Database** (em memória)
- **Spring Data JPA**
- **Spring Mail**
- **OkHttp** (cliente HTTP)
- **Maven**

## ⚙️ Configuração

### 1. Configurar Email SMTP

Edite o arquivo `src/main/resources/application.yml` ou defina as variáveis de ambiente:

```yaml
spring:
  mail:
    host: smtp.gmail.com
    port: 587
    username: ${EMAIL_USERNAME:seu-email@gmail.com}
    password: ${EMAIL_PASSWORD:sua-senha-de-app}
```

**Para Gmail:**
1. Ative a autenticação de 2 fatores
2. Gere uma senha de aplicativo em: https://myaccount.google.com/apppasswords
3. Use essa senha no campo `password`

### 2. Variáveis de Ambiente

```bash
export EMAIL_USERNAME=seu-email@gmail.com
export EMAIL_PASSWORD=sua-senha-de-app
```

## 🚀 Executando a Aplicação

### Opção 1: Maven (Aplicação completa)
```bash
mvn clean compile
mvn javafx:run
```

### Opção 2: Apenas API (sem JavaFX)
```bash
mvn spring-boot:run
```

### Opção 3: IDE
Execute a classe `EmailSenderApplication.java` no seu IDE

## 📝 Como Usar

### Interface JavaFX
1. Preencha os campos obrigatórios:
   - **De:** Seu email (deve corresponder ao configurado)
   - **Para:** Email(s) do destinatário (separados por vírgula)
   - **Assunto:** Assunto do email
   - **Mensagem:** Corpo do email
2. Campos opcionais:
   - **CC/BCC:** Cópia e cópia oculta
   - **HTML:** Marque para enviar como HTML
   - **Anexos:** Clique em "Adicionar Anexo"
3. Clique em "Enviar Email"
4. Acompanhe o status e histórico na parte inferior

### API REST

**Enviar Email:**
```bash
POST http://localhost:8080/api/email/send
Content-Type: application/json

{
  "from": "seu-email@gmail.com",
  "to": ["destinatario@exemplo.com"],
  "subject": "Teste de Email",
  "body": "Corpo do email",
  "isHtml": false
}
```

**Buscar Histórico:**
```bash
GET http://localhost:8080/api/email/logs
```

**Estatísticas:**
```bash
GET http://localhost:8080/api/email/statistics
```

## 🗂️ Estrutura do Projeto

```
src/main/java/com/emailapi/
├── EmailSenderApiApplication.java       # Aplicação Spring Boot
├── config/
│   └── MailConfig.java                 # Configuração SMTP
├── controller/
│   └── EmailController.java            # REST Controller
├── dto/
│   ├── EmailRequest.java               # Request DTO
│   └── EmailResponse.java              # Response DTO
├── entity/
│   └── EmailLog.java                   # Entidade JPA
├── repository/
│   └── EmailLogRepository.java         # Repository JPA
├── service/
│   └── EmailService.java               # Lógica de negócio
└── javafx/
    ├── EmailSenderApplication.java     # Aplicação JavaFX
    ├── controller/
    │   └── EmailSenderController.java  # Controller JavaFX
    └── service/
        └── EmailApiService.java        # Cliente HTTP

src/main/resources/
├── application.yml                     # Configurações Spring
├── fxml/
│   └── email-sender.fxml              # Layout JavaFX
└── css/
    └── email-sender.css               # Estilos CSS
```

## 🔧 Configurações Avançadas

### Diferentes Provedores SMTP

**Gmail:**
```yaml
spring.mail:
  host: smtp.gmail.com
  port: 587
```

**Outlook:**
```yaml
spring.mail:
  host: smtp-mail.outlook.com
  port: 587
```

**Yahoo:**
```yaml
spring.mail:
  host: smtp.mail.yahoo.com
  port: 587
```

### Database H2 Console
Acesse: http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:mem:emaildb`
- User: `sa`
- Password: (vazio)

## 🚨 Troubleshooting

### Erro de Autenticação
- Verifique se está usando a senha de aplicativo (não a senha da conta)
- Confirme se a autenticação de 2 fatores está ativada

### JavaFX não inicia
- Verifique se está usando Java 17+
- Execute com `mvn javafx:run` em vez de `java -jar`

### Erro de conexão API
- Certifique-se que o Spring Boot está rodando na porta 8080
- Verifique se não há firewall bloqueando a conexão

## 📊 Endpoints da API

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/email/send` | Enviar email |
| POST | `/api/email/send-async` | Enviar email assíncrono |
| GET | `/api/email/logs` | Buscar todos os logs |
| GET | `/api/email/logs/status/{status}` | Logs por status |
| GET | `/api/email/logs/date-range` | Logs por período |
| GET | `/api/email/statistics` | Estatísticas |
| GET | `/api/email/health` | Health check |

## 📄 Licença

MIT License - veja o arquivo LICENSE para detalhes.