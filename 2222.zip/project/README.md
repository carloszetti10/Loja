# Formulário de Cadastro de Agente - JavaFX

Este projeto implementa um formulário moderno e elegante para cadastro de agentes usando JavaFX e FXML.

## Características

- **Design Moderno**: Interface clean com cantos arredondados, sombras e tipografia profissional
- **Tamanho Fixo**: Janela de 600x600px não redimensionável, centralizada na tela
- **Campos Validados**: Nome, CPF (com formatação automática), Usuário e Senha
- **Seleção de Categorias**: Sistema sofisticado com duas listas e botões de controle
- **Feedback Visual**: Animações, hover effects e validações em tempo real

## Estrutura do Projeto

```
src/
├── main/
│   ├── java/com/example/
│   │   ├── AgentRegistrationApp.java      # Classe principal
│   │   └── AgentRegistrationController.java # Controller do FXML
│   └── resources/
│       ├── fxml/
│       │   └── AgentRegistration.fxml     # Layout da interface
│       └── css/
│           └── styles.css                 # Estilos CSS
└── pom.xml                               # Configuração Maven
```

## Funcionalidades

### Campos de Entrada
- **Nome Completo**: TextField padrão
- **CPF**: TextField com formatação automática (000.000.000-00)
- **Usuário**: TextField para nome de usuário
- **Senha**: PasswordField para entrada segura

### Seleção de Categorias
- Lista de categorias disponíveis (esquerda)
- Lista de categorias selecionadas (direita)
- Botões ▶ e ◀ para mover categorias entre listas
- Suporte a seleção múltipla
- Double-click para movimentação rápida
- Ordenação automática alfabética

### Validações
- Campos obrigatórios não podem estar vazios
- Pelo menos uma categoria deve ser selecionada
- Feedback visual para erros de validação

## Como Executar

### Pré-requisitos
- Java 11 ou superior
- Maven 3.6 ou superior

### Executando o Projeto

1. Clone ou baixe o projeto
2. Navegue até o diretório do projeto
3. Execute o comando:

```bash
mvn javafx:run
```

Ou compile e execute manualmente:

```bash
mvn compile
mvn exec:java -Dexec.mainClass="com.example.AgentRegistrationApp"
```

## Tecnologias Utilizadas

- **JavaFX 17**: Framework para interface gráfica
- **FXML**: Linguagem de marcação para layouts
- **CSS**: Estilização da interface
- **Maven**: Gerenciamento de dependências

## Personalização

### Modificando Categorias
Edite o método `setupCategories()` no `AgentRegistrationController.java` para alterar as categorias disponíveis.

### Alterando Estilos
Modifique o arquivo `styles.css` para personalizar cores, fontes e efeitos visuais.

### Validações Customizadas
Adicione novas validações no método `cadastrar()` do controller.

## Estrutura de Dados

O formulário coleta os dados em uma classe `AgentData` que contém:
- Nome completo
- CPF formatado
- Nome de usuário
- Senha
- Lista de categorias selecionadas

Os dados são exibidos no console após o cadastro bem-sucedido.