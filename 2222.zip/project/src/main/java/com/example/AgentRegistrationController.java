package com.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class AgentRegistrationController implements Initializable {

    @FXML private TextField nomeCompletoField;
    @FXML private TextField cpfField;
    @FXML private TextField usuarioField;
    @FXML private PasswordField senhaField;
    @FXML private VBox categoriesContainer;
    @FXML private Label selectedCountLabel;
    @FXML private Button clearAllBtn;
    @FXML private Button cancelarBtn;
    @FXML private Button cadastrarBtn;

    private Map<String, CheckBox> categoryCheckBoxes;
    private List<String> availableCategories;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupCategories();
        setupCPFFormatting();
    }

    private void setupCategories() {
        // Inicializa as categorias disponíveis
        availableCategories = List.of(
            "Vendas",
            "Marketing", 
            "Suporte Técnico",
            "Financeiro",
            "Recursos Humanos",
            "Operações",
            "Tecnologia da Informação",
            "Jurídico"
        );
        
        categoryCheckBoxes = new HashMap<>();
        
        // Cria os CheckBoxes para cada categoria
        for (String category : availableCategories) {
            CheckBox checkBox = new CheckBox(category);
            checkBox.setStyleClass("category-checkbox");
            
            // Adiciona listener para atualizar o contador
            checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                updateSelectedCount();
                updateCheckBoxStyles();
            });
            
            categoryCheckBoxes.put(category, checkBox);
            categoriesContainer.getChildren().add(checkBox);
        }
        
        updateSelectedCount();
    }
    
    private void updateSelectedCount() {
        long selectedCount = categoryCheckBoxes.values().stream()
            .mapToLong(cb -> cb.isSelected() ? 1 : 0)
            .sum();
            
        String text = selectedCount == 0 ? "Nenhuma categoria selecionada" :
                     selectedCount == 1 ? "1 categoria selecionada" :
                     selectedCount + " categorias selecionadas";
                     
        selectedCountLabel.setText(text);
        
        // Atualiza a visibilidade do botão "Limpar Tudo"
        clearAllBtn.setVisible(selectedCount > 0);
    }
    
    private void updateCheckBoxStyles() {
        categoryCheckBoxes.values().forEach(checkBox -> {
            if (checkBox.isSelected()) {
                checkBox.getStyleClass().removeAll("category-checkbox");
                checkBox.getStyleClass().add("category-checkbox-selected");
            } else {
                checkBox.getStyleClass().removeAll("category-checkbox-selected");
                checkBox.getStyleClass().add("category-checkbox");
            }
        });
    }

    private void setupCPFFormatting() {
        cpfField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                // Remove todos os caracteres não numéricos
                String digits = newValue.replaceAll("\\D", "");
                
                // Limita a 11 dígitos
                if (digits.length() > 11) {
                    digits = digits.substring(0, 11);
                }
                
                // Aplica a formatação
                String formatted = formatCPF(digits);
                
                // Atualiza o campo apenas se necessário para evitar loop infinito
                if (!formatted.equals(newValue)) {
                    cpfField.setText(formatted);
                    cpfField.positionCaret(formatted.length());
                }
            }
        });
    }

    private String formatCPF(String digits) {
        if (digits.length() <= 3) {
            return digits;
        } else if (digits.length() <= 6) {
            return digits.substring(0, 3) + "." + digits.substring(3);
        } else if (digits.length() <= 9) {
            return digits.substring(0, 3) + "." + digits.substring(3, 6) + "." + digits.substring(6);
        } else {
            return digits.substring(0, 3) + "." + digits.substring(3, 6) + "." + 
                   digits.substring(6, 9) + "-" + digits.substring(9);
        }
    }

    @FXML
    private void clearAllCategories() {
        categoryCheckBoxes.values().forEach(checkBox -> checkBox.setSelected(false));
    }

    @FXML
    private void cancelar() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmação");
        alert.setHeaderText("Cancelar Cadastro");
        alert.setContentText("Deseja realmente cancelar? Todos os dados serão perdidos.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            // Limpa todos os campos
            nomeCompletoField.clear();
            cpfField.clear();
            usuarioField.clear();
            senhaField.clear();
            
            // Desmarca todas as categorias
            categoryCheckBoxes.values().forEach(checkBox -> checkBox.setSelected(false));
        }
    }

    @FXML
    private void cadastrar() {
        // Validação dos campos
        if (nomeCompletoField.getText().trim().isEmpty() ||
            cpfField.getText().trim().isEmpty() ||
            usuarioField.getText().trim().isEmpty() ||
            senhaField.getText().trim().isEmpty()) {
            
            showAlert("Erro", "Por favor, preencha todos os campos obrigatórios.", Alert.AlertType.ERROR);
            return;
        }

        // Verifica se pelo menos uma categoria foi selecionada
        List<String> selectedCategories = getSelectedCategories();
        if (selectedCategories.isEmpty()) {
            showAlert("Erro", "Por favor, selecione pelo menos uma categoria.", Alert.AlertType.ERROR);
            return;
        }

        // Simula o cadastro
        cadastrarBtn.setText("Cadastrando...");
        cadastrarBtn.setDisable(true);

        PauseTransition pause = new PauseTransition(Duration.millis(1500));
        pause.setOnFinished(e -> {
            // Coleta os dados
            AgentData agentData = new AgentData(
                nomeCompletoField.getText().trim(),
                cpfField.getText().trim(),
                usuarioField.getText().trim(),
                senhaField.getText().trim(),
                selectedCategories
            );

            // Exibe os dados (em uma aplicação real, salvaria no banco de dados)
            System.out.println("Dados do agente cadastrado:");
            System.out.println("Nome: " + agentData.getNomeCompleto());
            System.out.println("CPF: " + agentData.getCpf());
            System.out.println("Usuário: " + agentData.getUsuario());
            System.out.println("Categorias: " + agentData.getCategorias());

            showAlert("Sucesso", "Agente cadastrado com sucesso!", Alert.AlertType.INFORMATION);
            
            // Restaura o botão
            cadastrarBtn.setText("Cadastrar");
            cadastrarBtn.setDisable(false);
        });
        pause.play();
    }

    private List<String> getSelectedCategories() {
        return categoryCheckBoxes.entrySet().stream()
            .filter(entry -> entry.getValue().isSelected())
            .map(Map.Entry::getKey)
            .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Classe para armazenar os dados do agente
    public static class AgentData {
        private String nomeCompleto;
        private String cpf;
        private String usuario;
        private String senha;
        private List<String> categorias;

        public AgentData(String nomeCompleto, String cpf, String usuario, String senha, List<String> categorias) {
            this.nomeCompleto = nomeCompleto;
            this.cpf = cpf;
            this.usuario = usuario;
            this.senha = senha;
            this.categorias = categorias;
        }

        // Getters
        public String getNomeCompleto() { return nomeCompleto; }
        public String getCpf() { return cpf; }
        public String getUsuario() { return usuario; }
        public String getSenha() { return senha; }
        public List<String> getCategorias() { return categorias; }
    }
}