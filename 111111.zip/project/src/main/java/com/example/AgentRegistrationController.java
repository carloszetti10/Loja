package com.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

public class AgentRegistrationController implements Initializable {

    @FXML private TextField nomeCompletoField;
    @FXML private TextField cpfField;
    @FXML private TextField usuarioField;
    @FXML private PasswordField senhaField;
    @FXML private ListView<String> availableCategoriesList;
    @FXML private ListView<String> selectedCategoriesList;
    @FXML private Button addCategoryBtn;
    @FXML private Button removeCategoryBtn;
    @FXML private Button cancelarBtn;
    @FXML private Button cadastrarBtn;

    private ObservableList<String> availableCategories;
    private ObservableList<String> selectedCategories;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupCategories();
        setupCPFFormatting();
        setupDoubleClickHandlers();
    }

    private void setupCategories() {
        // Inicializa as listas de categorias
        availableCategories = FXCollections.observableArrayList(
            "Vendas",
            "Marketing", 
            "Suporte Técnico",
            "Financeiro",
            "Recursos Humanos",
            "Operações",
            "Tecnologia da Informação",
            "Jurídico"
        );
        
        selectedCategories = FXCollections.observableArrayList();
        
        availableCategoriesList.setItems(availableCategories);
        selectedCategoriesList.setItems(selectedCategories);
        
        // Permite seleção múltipla
        availableCategoriesList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        selectedCategoriesList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    private void setupCPFFormatting() {
        cpfField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                // Remove todos os caracteres não numéricos
                String digits = newValue.replaceAll("\\D", "");
                
                // Limita a 11 dígitos
                if (digits.length() > 11) {
                    digits = digits.substring(0, 11);
                }
                
                // Aplica a formatação
                String formatted = formatCPF(digits);
                
                // Atualiza o campo apenas se necessário para evitar loop infinito
                if (!formatted.equals(newValue)) {
                    cpfField.setText(formatted);
                    cpfField.positionCaret(formatted.length());
                }
            }
        });
    }

    private String formatCPF(String digits) {
        if (digits.length() <= 3) {
            return digits;
        } else if (digits.length() <= 6) {
            return digits.substring(0, 3) + "." + digits.substring(3);
        } else if (digits.length() <= 9) {
            return digits.substring(0, 3) + "." + digits.substring(3, 6) + "." + digits.substring(6);
        } else {
            return digits.substring(0, 3) + "." + digits.substring(3, 6) + "." + 
                   digits.substring(6, 9) + "-" + digits.substring(9);
        }
    }

    private void setupDoubleClickHandlers() {
        availableCategoriesList.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                addCategory();
            }
        });

        selectedCategoriesList.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                removeCategory();
            }
        });
    }

    @FXML
    private void addCategory() {
        List<String> selected = new ArrayList<>(availableCategoriesList.getSelectionModel().getSelectedItems());
        
        if (selected.isEmpty()) {
            // Feedback visual quando nenhuma categoria está selecionada
            availableCategoriesList.setStyle("-fx-border-color: #e74c3c; -fx-border-width: 2px;");
            PauseTransition pause = new PauseTransition(Duration.millis(300));
            pause.setOnFinished(e -> availableCategoriesList.setStyle(""));
            pause.play();
            return;
        }

        for (String category : selected) {
            availableCategories.remove(category);
            selectedCategories.add(category);
        }
        
        // Ordena as listas
        Collections.sort(availableCategories);
        Collections.sort(selectedCategories);
        
        availableCategoriesList.getSelectionModel().clearSelection();
    }

    @FXML
    private void removeCategory() {
        List<String> selected = new ArrayList<>(selectedCategoriesList.getSelectionModel().getSelectedItems());
        
        if (selected.isEmpty()) {
            // Feedback visual quando nenhuma categoria está selecionada
            selectedCategoriesList.setStyle("-fx-border-color: #e74c3c; -fx-border-width: 2px;");
            PauseTransition pause = new PauseTransition(Duration.millis(300));
            pause.setOnFinished(e -> selectedCategoriesList.setStyle(""));
            pause.play();
            return;
        }

        for (String category : selected) {
            selectedCategories.remove(category);
            availableCategories.add(category);
        }
        
        // Ordena as listas
        Collections.sort(availableCategories);
        Collections.sort(selectedCategories);
        
        selectedCategoriesList.getSelectionModel().clearSelection();
    }

    @FXML
    private void cancelar() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmação");
        alert.setHeaderText("Cancelar Cadastro");
        alert.setContentText("Deseja realmente cancelar? Todos os dados serão perdidos.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            // Limpa todos os campos
            nomeCompletoField.clear();
            cpfField.clear();
            usuarioField.clear();
            senhaField.clear();
            
            // Move todas as categorias selecionadas de volta para disponíveis
            availableCategories.addAll(selectedCategories);
            selectedCategories.clear();
            Collections.sort(availableCategories);
        }
    }

    @FXML
    private void cadastrar() {
        // Validação dos campos
        if (nomeCompletoField.getText().trim().isEmpty() ||
            cpfField.getText().trim().isEmpty() ||
            usuarioField.getText().trim().isEmpty() ||
            senhaField.getText().trim().isEmpty()) {
            
            showAlert("Erro", "Por favor, preencha todos os campos obrigatórios.", Alert.AlertType.ERROR);
            return;
        }

        if (selectedCategories.isEmpty()) {
            showAlert("Erro", "Por favor, selecione pelo menos uma categoria.", Alert.AlertType.ERROR);
            return;
        }

        // Simula o cadastro
        cadastrarBtn.setText("Cadastrando...");
        cadastrarBtn.setDisable(true);

        PauseTransition pause = new PauseTransition(Duration.millis(1500));
        pause.setOnFinished(e -> {
            // Coleta os dados
            AgentData agentData = new AgentData(
                nomeCompletoField.getText().trim(),
                cpfField.getText().trim(),
                usuarioField.getText().trim(),
                senhaField.getText().trim(),
                new ArrayList<>(selectedCategories)
            );

            // Exibe os dados (em uma aplicação real, salvaria no banco de dados)
            System.out.println("Dados do agente cadastrado:");
            System.out.println("Nome: " + agentData.getNomeCompleto());
            System.out.println("CPF: " + agentData.getCpf());
            System.out.println("Usuário: " + agentData.getUsuario());
            System.out.println("Categorias: " + agentData.getCategorias());

            showAlert("Sucesso", "Agente cadastrado com sucesso!", Alert.AlertType.INFORMATION);
            
            // Restaura o botão
            cadastrarBtn.setText("Cadastrar");
            cadastrarBtn.setDisable(false);
        });
        pause.play();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Classe para armazenar os dados do agente
    public static class AgentData {
        private String nomeCompleto;
        private String cpf;
        private String usuario;
        private String senha;
        private List<String> categorias;

        public AgentData(String nomeCompleto, String cpf, String usuario, String senha, List<String> categorias) {
            this.nomeCompleto = nomeCompleto;
            this.cpf = cpf;
            this.usuario = usuario;
            this.senha = senha;
            this.categorias = categorias;
        }

        // Getters
        public String getNomeCompleto() { return nomeCompleto; }
        public String getCpf() { return cpf; }
        public String getUsuario() { return usuario; }
        public String getSenha() { return senha; }
        public List<String> getCategorias() { return categorias; }
    }
}