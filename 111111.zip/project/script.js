document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const cpfInput = document.getElementById('cpf');
    const availableCategories = document.getElementById('availableCategories');
    const selectedCategories = document.getElementById('selectedCategories');
    const addButton = document.getElementById('addCategory');
    const removeButton = document.getElementById('removeCategory');
    const cancelButton = document.querySelector('.btn-cancel');
    const submitButton = document.querySelector('.btn-submit');
    const form = document.querySelector('.registration-form');

    // Formatação automática do CPF
    cpfInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        e.target.value = value;
    });

    // Função para mover categorias
    function moveOptions(fromSelect, toSelect) {
        const selectedOptions = Array.from(fromSelect.selectedOptions);
        
        if (selectedOptions.length === 0) {
            // Animação de feedback quando nenhuma opção está selecionada
            fromSelect.style.borderColor = '#e74c3c';
            setTimeout(() => {
                fromSelect.style.borderColor = '#e1e8ed';
            }, 300);
            return;
        }

        selectedOptions.forEach(option => {
            // Clona a opção e adiciona à lista de destino
            const newOption = option.cloneNode(true);
            toSelect.appendChild(newOption);
            
            // Remove da lista de origem
            option.remove();
        });

        // Ordena as opções alfabeticamente
        sortSelectOptions(toSelect);
    }

    // Função para ordenar opções do select
    function sortSelectOptions(selectElement) {
        const options = Array.from(selectElement.options);
        options.sort((a, b) => a.text.localeCompare(b.text));
        
        // Remove todas as opções
        selectElement.innerHTML = '';
        
        // Adiciona as opções ordenadas
        options.forEach(option => {
            selectElement.appendChild(option);
        });
    }

    // Event listeners para os botões de adicionar/remover
    addButton.addEventListener('click', function() {
        moveOptions(availableCategories, selectedCategories);
    });

    removeButton.addEventListener('click', function() {
        moveOptions(selectedCategories, availableCategories);
    });

    // Double-click para mover categorias
    availableCategories.addEventListener('dblclick', function() {
        moveOptions(availableCategories, selectedCategories);
    });

    selectedCategories.addEventListener('dblclick', function() {
        moveOptions(selectedCategories, availableCategories);
    });

    // Botão cancelar
    cancelButton.addEventListener('click', function() {
        if (confirm('Deseja realmente cancelar? Todos os dados serão perdidos.')) {
            // Reset do formulário
            form.reset();
            
            // Move todas as categorias selecionadas de volta para disponíveis
            while (selectedCategories.options.length > 0) {
                availableCategories.appendChild(selectedCategories.options[0]);
            }
            sortSelectOptions(availableCategories);
            
            // Animação de feedback
            const container = document.querySelector('.form-container');
            container.style.transform = 'scale(0.98)';
            setTimeout(() => {
                container.style.transform = 'scale(1)';
            }, 150);
        }
    });

    // Submit do formulário
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validação básica
        const nome = document.getElementById('nomeCompleto').value.trim();
        const cpf = document.getElementById('cpf').value.trim();
        const usuario = document.getElementById('usuario').value.trim();
        const senha = document.getElementById('senha').value.trim();
        
        if (!nome || !cpf || !usuario || !senha) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        if (selectedCategories.options.length === 0) {
            alert('Por favor, selecione pelo menos uma categoria.');
            return;
        }

        // Coleta os dados do formulário
        const formData = {
            nomeCompleto: nome,
            cpf: cpf,
            usuario: usuario,
            senha: senha,
            categorias: Array.from(selectedCategories.options).map(option => ({
                value: option.value,
                text: option.text
            }))
        };

        // Animação de sucesso
        submitButton.style.backgroundColor = '#27ae60';
        submitButton.textContent = 'Cadastrando...';
        submitButton.disabled = true;

        // Simula o envio dos dados
        setTimeout(() => {
            console.log('Dados do agente:', formData);
            alert('Agente cadastrado com sucesso!');
            
            // Reset do botão
            submitButton.style.backgroundColor = '#27ae60';
            submitButton.textContent = 'Cadastrar';
            submitButton.disabled = false;
        }, 1500);
    });

    // Adiciona efeitos visuais nos campos de input
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentNode.style.transform = 'translateY(-1px)';
        });
        
        input.addEventListener('blur', function() {
            this.parentNode.style.transform = 'translateY(0)';
        });
    });

    // Melhora a experiência com as teclas
    document.addEventListener('keydown', function(e) {
        // Enter para adicionar categoria selecionada
        if (e.key === 'Enter' && availableCategories === document.activeElement) {
            e.preventDefault();
            moveOptions(availableCategories, selectedCategories);
        }
        
        // Delete/Backspace para remover categoria selecionada
        if ((e.key === 'Delete' || e.key === 'Backspace') && selectedCategories === document.activeElement) {
            e.preventDefault();
            moveOptions(selectedCategories, availableCategories);
        }
    });
});